#include <iostream>
#include "BigDecimalIntclass.h"
#include "BigReal.h"

int main() {
    BigReal mario("97.54"), malak("97.54");
  cout<< (malak == mario)<<endl;
cout<<"enter realnumber"<<endl;
cin>>mario;
cout<<mario;

}

